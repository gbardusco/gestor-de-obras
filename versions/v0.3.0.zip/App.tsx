
import React, { useState, useMemo, useRef, useEffect } from 'react';
import { WorkItem, DEFAULT_THEME, ItemType, Project, PDFTheme, ProjectAsset, ProjectExpense } from './types';
import { treeService } from './services/treeService';
import { excelService, ImportResult } from './services/excelService';
import { TreeTable } from './components/TreeTable';
import { ThemeEditor } from './components/ThemeEditor';
import { WorkItemModal } from './components/WorkItemModal';
import { EvolutionChart } from './components/EvolutionChart';
import { PrintReport } from './components/PrintReport';
import { AssetManager } from './components/AssetManager';
import { ExpenseManager } from './components/ExpenseManager';
import { financial } from './utils/math';
import { useProjectState } from './hooks/useProjectState';
import { 
  Plus, 
  TrendingUp,
  Database,
  Moon,
  Sun,
  HardHat,
  Search,
  Briefcase,
  PieChart,
  Layers,
  FileSpreadsheet,
  UploadCloud,
  Menu,
  CheckCircle2,
  Printer,
  Trash2,
  Edit2,
  Percent,
  Download,
  Lock,
  Undo2,
  Redo2,
  ChevronRight,
  Settings,
  PlusCircle,
  BarChart3,
  Home,
  Clock,
  AlertTriangle,
  FileText,
  DollarSign,
  Wallet,
  X
} from 'lucide-react';

type ViewMode = 'global-dashboard' | 'project-workspace' | 'system-settings';
type ProjectTab = 'wbs' | 'branding' | 'stats' | 'documents' | 'expenses';

const App: React.FC = () => {
  const { 
    projects, 
    activeProject, 
    activeProjectId, 
    setActiveProjectId, 
    updateActiveProject, 
    updateProjects,
    finalizeMeasurement,
    undo,
    redo,
    canUndo,
    canRedo
  } = useProjectState();

  const [viewMode, setViewMode] = useState<ViewMode>('global-dashboard');
  const [projectTab, setProjectTab] = useState<ProjectTab>('wbs');
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set());
  const [selectedSnapshot, setSelectedSnapshot] = useState<number | null>(null);
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalType, setModalType] = useState<ItemType>('item');
  const [editingItem, setEditingItem] = useState<WorkItem | null>(null);
  const [targetParentId, setTargetParentId] = useState<string | null>(null);
  const [renameModal, setRenameModal] = useState({ isOpen: false, id: '', name: '' });
  const [deleteModal, setDeleteModal] = useState({ isOpen: false, id: '' });
  const [closeMeasurementModal, setCloseMeasurementModal] = useState(false);
  const [importSummary, setImportSummary] = useState<ImportResult | null>(null);
  const [isImporting, setIsImporting] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const currentItems = useMemo(() => {
    if (!activeProject) return [];
    if (selectedSnapshot === null) return activeProject.items;
    const snap = activeProject.history?.find(h => h.measurementNumber === selectedSnapshot);
    return snap ? snap.items : [];
  }, [activeProject, selectedSnapshot]);

  const isReadOnly = selectedSnapshot !== null;

  const processedTree = useMemo(() => {
    if (!activeProject) return [];
    const tree = treeService.buildTree(currentItems);
    return tree.map((root, idx) => treeService.processRecursive(root, '', idx, activeProject.bdi));
  }, [activeProject, currentItems]);

  const flattenedList = useMemo(() => 
    treeService.flattenTree(processedTree, expandedIds)
  , [processedTree, expandedIds]);

  const stats = useMemo(() => {
    const totals = {
      contract: financial.sum(processedTree.map(n => n.contractTotal || 0)),
      current: financial.sum(processedTree.map(n => n.currentTotal || 0)),
      accumulated: financial.sum(processedTree.map(n => n.accumulatedTotal || 0)),
      balance: financial.sum(processedTree.map(n => n.balanceTotal || 0)),
      expenses: financial.sum((activeProject?.expenses || []).map(e => e.amount))
    };
    return { 
      ...totals, 
      progress: totals.contract > 0 ? (totals.accumulated / totals.contract) * 100 : 0,
      margin: totals.accumulated - totals.expenses
    };
  }, [processedTree, activeProject?.expenses]);

  useEffect(() => {
    setSelectedSnapshot(null);
  }, [activeProjectId]);

  const handleOpenProject = (id: string) => {
    setActiveProjectId(id);
    setViewMode('project-workspace');
    setProjectTab('wbs');
    setSelectedSnapshot(null);
    setMobileMenuOpen(false);
  };

  const handleCreateProject = () => {
    const newProj: Project = {
      id: crypto.randomUUID(),
      name: 'Novo Empreendimento',
      companyName: 'Sua Empresa de Engenharia',
      measurementNumber: 1,
      referenceDate: new Date().toLocaleDateString('pt-BR'),
      logo: null,
      items: [],
      history: [],
      theme: { ...DEFAULT_THEME },
      bdi: 25,
      assets: [],
      expenses: [],
      config: { strict: false, printCards: true, printSubtotals: true }
    };
    updateProjects([...projects, newProj]);
    handleOpenProject(newProj.id);
  };

  const handleReorder = (sourceId: string, targetId: string, position: 'before' | 'after' | 'inside') => {
    if (!activeProject) return;
    const newItems = treeService.reorderItems(activeProject.items, sourceId, targetId, position);
    updateActiveProject({ items: newItems });
  };

  const handleFileImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setIsImporting(true);
      try {
        const result = await excelService.parseAndValidate(file);
        if (result.items.length === 0) {
          alert("Nenhum item válido foi encontrado na planilha.");
        } else {
          setImportSummary(result);
        }
      } catch (error: any) {
        alert(`Erro ao importar: ${error.message}`);
      } finally {
        setIsImporting(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    }
  };

  const handleAddAsset = (asset: ProjectAsset) => {
    if (!activeProject) return;
    updateActiveProject({ assets: [...(activeProject.assets || []), asset] });
  };

  const handleDeleteAsset = (id: string) => {
    if (!activeProject) return;
    updateActiveProject({ assets: (activeProject.assets || []).filter(a => a.id !== id) });
  };

  const handleAddExpense = (expense: ProjectExpense) => {
    if (!activeProject) return;
    updateActiveProject({ expenses: [...(activeProject.expenses || []), expense] });
  };

  const handleUpdateExpense = (id: string, data: Partial<ProjectExpense>) => {
    if (!activeProject) return;
    updateActiveProject({ 
      expenses: (activeProject.expenses || []).map(e => e.id === id ? { ...e, ...data } : e) 
    });
  };

  const handleDeleteExpense = (id: string) => {
    if (!activeProject) return;
    updateActiveProject({ expenses: (activeProject.expenses || []).filter(e => e.id !== id) });
  };

  return (
    <div className={`flex h-screen bg-slate-50 dark:bg-slate-950 overflow-hidden text-slate-900 dark:text-slate-100 ${isDarkMode ? 'dark' : ''}`}>
      <input type="file" ref={fileInputRef} className="hidden" accept=".xlsx, .xls" onChange={handleFileImport} />

      {/* MOBILE OVERLAY */}
      {mobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-slate-950/50 backdrop-blur-sm z-[60] lg:hidden"
          onClick={() => setMobileMenuOpen(false)}
        />
      )}

      {/* SIDEBAR */}
      <aside className={`
        fixed inset-y-0 left-0 z-[70] lg:relative lg:flex flex-col bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 transition-all duration-300 no-print
        ${sidebarOpen ? 'w-64' : 'w-20'}
        ${mobileMenuOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        <div className="h-20 flex items-center justify-between px-6 border-b border-slate-100 dark:border-slate-800 shrink-0">
          <div className="flex items-center">
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white shrink-0 shadow-lg shadow-indigo-500/20">
              <HardHat size={18} />
            </div>
            {sidebarOpen && <span className="ml-3 text-sm font-black tracking-tight uppercase">ProMeasure</span>}
          </div>
          <button onClick={() => setMobileMenuOpen(false)} className="lg:hidden p-2 text-slate-400">
            <X size={20} />
          </button>
        </div>

        <nav className="flex-1 p-4 space-y-1 overflow-y-auto custom-scrollbar">
          <NavItem active={viewMode === 'global-dashboard'} onClick={() => { setViewMode('global-dashboard'); setMobileMenuOpen(false); }} icon={<Home size={18}/>} label="Dashboard" open={sidebarOpen} />
          <NavItem active={viewMode === 'system-settings'} onClick={() => { setViewMode('system-settings'); setMobileMenuOpen(false); }} icon={<Settings size={18}/>} label="Configurações" open={sidebarOpen} />
          
          <div className="pt-6 pb-2 px-3">
             {sidebarOpen ? (
               <div className="flex items-center justify-between">
                 <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Meus Projetos</h3>
                 <button onClick={handleCreateProject} className="text-indigo-500 hover:text-indigo-600"><PlusCircle size={14}/></button>
               </div>
             ) : <div className="h-px bg-slate-100 dark:bg-slate-800 mx-2" />}
          </div>

          <div className="space-y-1">
            {projects.map(p => (
              <button key={p.id} onClick={() => handleOpenProject(p.id)} className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all ${activeProjectId === p.id && viewMode === 'project-workspace' ? 'bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 font-bold' : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800'}`}>
                <Briefcase size={16} className="shrink-0" />
                {sidebarOpen && <span className="text-[11px] truncate">{p.name}</span>}
              </button>
            ))}
          </div>
        </nav>

        <div className="p-4 border-t border-slate-100 dark:border-slate-800 space-y-2">
          <button onClick={() => setIsDarkMode(!isDarkMode)} className="w-full flex items-center gap-3 p-3 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-all">
            {isDarkMode ? <Sun size={18}/> : <Moon size={18}/>}
            {sidebarOpen && <span className="text-[11px] font-bold uppercase tracking-widest">{isDarkMode ? 'Claro' : 'Escuro'}</span>}
          </button>
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="hidden lg:flex w-full items-center gap-3 p-3 text-slate-400 hover:text-slate-600 rounded-xl">
             <Menu size={18} />
             {sidebarOpen && <span className="text-[11px] font-bold uppercase tracking-widest">Recolher</span>}
          </button>
        </div>
      </aside>

      {/* MAIN CONTENT */}
      <main className="flex-1 flex flex-col min-w-0 bg-slate-50 dark:bg-slate-950 overflow-hidden relative no-print">
        {/* MOBILE HEADER BUTTON */}
        <div className="lg:hidden h-16 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex items-center px-6 shrink-0 z-[50]">
          <button onClick={() => setMobileMenuOpen(true)} className="p-2 -ml-2 text-slate-600 dark:text-slate-300">
            <Menu size={24} />
          </button>
          <span className="ml-4 text-xs font-black uppercase tracking-widest truncate">
            {viewMode === 'global-dashboard' ? 'Dashboard' : activeProject?.name}
          </span>
        </div>

        {viewMode === 'global-dashboard' && (
          <div className="flex-1 overflow-y-auto p-4 sm:p-8 md:p-12 custom-scrollbar animate-in fade-in duration-500">
             <div className="max-w-6xl mx-auto space-y-8 sm:space-y-12">
                <header className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
                   <div>
                      <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-slate-800 dark:text-white">Central de Empreendimentos</h1>
                      <p className="text-sm text-slate-500 font-medium">Você possui {projects.length} obras cadastradas.</p>
                   </div>
                   <button onClick={handleCreateProject} className="w-full sm:w-auto flex items-center justify-center gap-2 px-8 py-4 bg-indigo-600 text-white font-black uppercase tracking-widest text-[10px] rounded-2xl shadow-xl shadow-indigo-500/20 hover:scale-105 active:scale-95 transition-all">
                      <Plus size={16} /> Novo Empreendimento
                   </button>
                </header>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
                   {projects.map(p => {
                      const projStats = treeService.calculateBasicStats(p.items, p.bdi);
                      return (
                        <div key={p.id} onClick={() => handleOpenProject(p.id)} className="group bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[2.5rem] p-6 sm:p-8 shadow-sm hover:shadow-2xl hover:border-indigo-500 transition-all cursor-pointer relative overflow-hidden">
                           <div className="relative z-10 flex justify-between items-start mb-6">
                              <div className="p-3 bg-indigo-50 dark:bg-indigo-900/40 text-indigo-600 rounded-2xl"><Briefcase size={20}/></div>
                              <div className="flex gap-1">
                                <button onClick={(e) => { e.stopPropagation(); setRenameModal({isOpen: true, id: p.id, name: p.name}); }} className="p-2 text-slate-400 hover:text-indigo-600 transition-all"><Edit2 size={16}/></button>
                                <button onClick={(e) => { e.stopPropagation(); setDeleteModal({isOpen: true, id: p.id}); }} className="p-2 text-slate-400 hover:text-rose-600 transition-all"><Trash2 size={16}/></button>
                              </div>
                           </div>
                           <h3 className="text-lg font-black text-slate-800 dark:text-white mb-2 truncate group-hover:text-indigo-600 transition-colors">{p.name}</h3>
                           <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mb-6">Medição: #{p.measurementNumber}</p>
                           <div className="space-y-4">
                              <div className="flex justify-between items-end">
                                 <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Progresso</span>
                                 <span className="text-sm font-black text-indigo-600">{projStats.progress.toFixed(1)}%</span>
                              </div>
                              <div className="h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                                 <div className="h-full bg-indigo-500 transition-all duration-1000" style={{ width: `${projStats.progress}%` }} />
                              </div>
                           </div>
                        </div>
                      )
                   })}
                </div>
             </div>
          </div>
        )}

        {viewMode === 'project-workspace' && activeProject && (
          <div className="flex-1 flex flex-col overflow-hidden">
             <header className="min-h-24 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex flex-col md:flex-row items-stretch md:items-center justify-between px-6 md:px-10 py-4 md:py-0 shrink-0 z-40 gap-4">
                <div className="flex flex-col gap-1 overflow-hidden">
                   <div className="hidden md:flex items-center gap-2 text-slate-400 text-[10px] font-black uppercase tracking-widest">
                      <Home size={12} className="cursor-pointer hover:text-indigo-500" onClick={() => setViewMode('global-dashboard')} />
                      <ChevronRight size={10} />
                      <span className="text-slate-500 truncate">{activeProject.name}</span>
                   </div>
                   <div className="flex items-center gap-4 overflow-x-auto custom-scrollbar pb-1 no-scrollbar">
                      <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-xl shadow-inner whitespace-nowrap">
                         <TabBtn active={projectTab === 'wbs'} onClick={() => setProjectTab('wbs')} label="Planilha" icon={<Layers size={14}/>} />
                         <TabBtn active={projectTab === 'stats'} onClick={() => setProjectTab('stats')} label="Análise" icon={<BarChart3 size={14}/>} />
                         <TabBtn active={projectTab === 'expenses'} onClick={() => setProjectTab('expenses')} label="Gastos" icon={<DollarSign size={14}/>} />
                         <TabBtn active={projectTab === 'documents'} onClick={() => setProjectTab('documents')} label="Docs" icon={<FileText size={14}/>} />
                      </div>
                      <div className="hidden sm:block h-8 w-px bg-slate-200 dark:bg-slate-800 mx-2" />
                      <div className="flex items-center gap-3 bg-indigo-50 dark:bg-indigo-900/20 px-4 py-2 rounded-2xl border border-indigo-100/50">
                         <Clock size={14} className="text-indigo-500 shrink-0" />
                         <select className="bg-transparent text-[10px] font-black uppercase tracking-widest text-indigo-700 dark:text-indigo-300 outline-none cursor-pointer max-w-[120px]" value={selectedSnapshot === null ? 'current' : selectedSnapshot} onChange={(e) => { const val = e.target.value; setSelectedSnapshot(val === 'current' ? null : parseInt(val)); }}>
                            <option value="current">#{activeProject.measurementNumber}</option>
                            {(activeProject.history || []).map(h => ( <option key={h.measurementNumber} value={h.measurementNumber}>#{h.measurementNumber} ({h.date})</option> ))}
                         </select>
                      </div>
                   </div>
                </div>

                <div className="flex items-center justify-between md:justify-end gap-2 sm:gap-4">
                   {!isReadOnly && (
                     <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
                        <button disabled={!canUndo} onClick={undo} className="p-2 hover:bg-white dark:hover:bg-slate-700 rounded-lg disabled:opacity-30 transition-all"><Undo2 size={16}/></button>
                        <button disabled={!canRedo} onClick={redo} className="p-2 hover:bg-white dark:hover:bg-slate-700 rounded-lg disabled:opacity-30 transition-all"><Redo2 size={16}/></button>
                     </div>
                   )}
                   <div className="flex items-center gap-2">
                    <button onClick={() => window.print()} className="p-3 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-2xl transition-all"><Printer size={18}/></button>
                    {!isReadOnly && (
                      <button onClick={() => setCloseMeasurementModal(true)} disabled={!stats.current && !activeProject.items.some(it => it.currentQuantity > 0)} className={`flex items-center gap-2 px-4 sm:px-6 py-3 rounded-2xl font-black uppercase text-[9px] sm:text-[10px] tracking-widest transition-all ${(stats.current || activeProject.items.some(it => it.currentQuantity > 0)) ? 'bg-indigo-600 text-white shadow-lg' : 'bg-slate-200 text-slate-400 cursor-not-allowed'}`}>
                          <Lock size={14}/> <span className="hidden xs:inline">Fechar Período</span>
                      </button>
                    )}
                   </div>
                </div>
             </header>

             <div className="flex-1 overflow-y-auto custom-scrollbar p-4 sm:p-6 md:p-10 bg-slate-50 dark:bg-slate-950">
                <div className="max-w-[1600px] mx-auto space-y-8">
                   {projectTab === 'wbs' && (
                     <div className="space-y-6 animate-in fade-in duration-300">
                        <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-6 bg-white dark:bg-slate-900 p-4 sm:p-6 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm">
                           <div className="flex flex-wrap items-center gap-2 sm:gap-3">
                              <button disabled={isReadOnly} onClick={() => { setTargetParentId(null); setModalType('item'); setEditingItem(null); setIsModalOpen(true); }} className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 sm:px-6 py-3 bg-indigo-600 disabled:opacity-30 text-white font-black uppercase tracking-widest text-[9px] rounded-xl shadow-lg shadow-indigo-500/10"><Plus size={14}/> Item</button>
                              <button disabled={isReadOnly} onClick={() => { setTargetParentId(null); setModalType('category'); setEditingItem(null); setIsModalOpen(true); }} className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 sm:px-6 py-3 bg-white dark:bg-slate-800 disabled:opacity-30 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-black uppercase tracking-widest text-[9px] rounded-xl"><Layers size={14}/> Grupo</button>
                              <div className="hidden sm:block w-px h-6 bg-slate-100 dark:bg-slate-800 mx-1" />
                              <button disabled={isReadOnly || isImporting} onClick={() => fileInputRef.current?.click()} className="flex items-center gap-2 px-3 py-3 text-slate-500 hover:text-emerald-600 transition-colors">
                                {isImporting ? <div className="w-4 h-4 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin" /> : <UploadCloud size={16}/>}
                                <span className="text-[9px] font-black uppercase tracking-widest">Importar</span>
                              </button>
                           </div>
                           <div className="relative w-full lg:w-96">
                              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                              <input placeholder="Buscar serviço..." className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700 pl-11 pr-4 py-3 rounded-xl text-xs outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
                           </div>
                        </div>

                        <div className="table-container">
                          <TreeTable 
                            data={flattenedList} expandedIds={expandedIds} 
                            onToggle={id => { const n = new Set(expandedIds); n.has(id) ? n.delete(id) : n.add(id); setExpandedIds(n); }} 
                            onExpandAll={() => setExpandedIds(new Set(currentItems.filter(i => i.type === 'category').map(i => i.id)))}
                            onCollapseAll={() => setExpandedIds(new Set())}
                            onDelete={id => !isReadOnly && updateActiveProject({ items: activeProject.items.filter(i => i.id !== id && i.parentId !== id) })}
                            onUpdateQuantity={(id, qty) => !isReadOnly && updateActiveProject({ items: activeProject.items.map(it => it.id === id ? { ...it, currentQuantity: qty } : it) })}
                            onUpdatePercentage={(id, pct) => !isReadOnly && updateActiveProject({ items: activeProject.items.map(it => it.id === id ? { ...it, currentQuantity: financial.round((pct/100) * it.contractQuantity), currentPercentage: pct } : it) })}
                            onAddChild={(pid, type) => { if(!isReadOnly) { setTargetParentId(pid); setModalType(type); setEditingItem(null); setIsModalOpen(true); } }}
                            onEdit={item => { if(!isReadOnly) { setEditingItem(item); setModalType(item.type); setIsModalOpen(true); } }}
                            onReorder={handleReorder}
                            searchQuery={searchQuery}
                            isReadOnly={isReadOnly}
                          />
                        </div>
                     </div>
                   )}

                   {projectTab === 'stats' && (
                     <div className="space-y-6 sm:space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4 sm:gap-6">
                           <KpiCard label="Contrato Total" value={financial.formatBRL(stats.contract)} icon={<Briefcase size={20}/>} progress={100} color="indigo" />
                           <KpiCard label="Acumulado" value={financial.formatBRL(stats.accumulated)} icon={<PieChart size={20}/>} progress={stats.progress} color="emerald" />
                           <KpiCard label="Gastos Reais" value={financial.formatBRL(stats.expenses)} icon={<Wallet size={20}/>} progress={(stats.expenses / stats.contract) * 100} color="rose" />
                           <KpiCard label="Res. Líquido" value={financial.formatBRL(stats.margin)} icon={<DollarSign size={20}/>} progress={(stats.margin / stats.accumulated) * 100} color={stats.margin >= 0 ? 'emerald' : 'rose'} highlight />
                           <KpiCard label="Saldo Obra" value={financial.formatBRL(stats.balance)} icon={<Database size={20}/>} progress={100 - stats.progress} color="slate" />
                        </div>
                        <div className="w-full overflow-hidden">
                          <EvolutionChart history={activeProject.history || []} currentProgress={stats.progress} />
                        </div>
                     </div>
                   )}

                   {projectTab === 'expenses' && (
                     <ExpenseManager 
                        expenses={activeProject.expenses || []} 
                        onAdd={handleAddExpense} 
                        onUpdate={handleUpdateExpense}
                        onDelete={handleDeleteExpense} 
                        workItems={activeProject.items}
                        measuredValue={stats.accumulated}
                        isReadOnly={isReadOnly}
                     />
                   )}

                   {projectTab === 'documents' && (
                     <AssetManager 
                        assets={activeProject.assets || []} 
                        onAdd={handleAddAsset} 
                        onDelete={handleDeleteAsset} 
                        isReadOnly={isReadOnly}
                     />
                   )}

                   {projectTab === 'branding' && (
                     <div className="space-y-8 animate-in fade-in duration-500">
                        <div className="bg-white dark:bg-slate-900 p-6 sm:p-10 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm max-w-4xl mx-auto">
                           <div className="flex items-center gap-4 mb-8">
                              <div className="p-3 sm:p-4 bg-emerald-600 rounded-2xl text-white"><Percent size={20} /></div>
                              <div>
                                <h3 className="text-lg sm:text-xl font-black text-slate-800 dark:text-white">Taxa de BDI</h3>
                                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Atualização automática de preços</p>
                              </div>
                           </div>
                           <div className="flex flex-col sm:grid sm:grid-cols-3 items-stretch gap-6 sm:gap-10">
                              <div className="sm:col-span-2">
                                 <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 block ml-1">Percentual (%)</label>
                                 <div className="relative">
                                    <input disabled={isReadOnly} type="number" className="w-full px-8 py-6 rounded-[2rem] border-2 border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-3xl sm:text-4xl font-black focus:border-indigo-500 outline-none pr-20 dark:text-slate-100 transition-all" value={activeProject.bdi} onChange={(e) => updateActiveProject({ bdi: parseFloat(e.target.value) || 0 })} />
                                    <span className="absolute right-8 top-1/2 -translate-y-1/2 text-2xl font-black text-slate-300">%</span>
                                 </div>
                              </div>
                              <div className="p-6 sm:p-8 bg-indigo-50 dark:bg-indigo-900/20 rounded-[2.5rem] border border-indigo-100 dark:border-indigo-800 text-center flex flex-col justify-center">
                                 <p className="text-[9px] font-black text-indigo-400 uppercase mb-1 tracking-widest">Multiplicador</p>
                                 <p className="text-3xl font-black text-indigo-600 dark:text-indigo-400">{(1 + activeProject.bdi/100).toFixed(4)}x</p>
                              </div>
                           </div>
                        </div>
                        <div className="overflow-x-auto">
                          <ThemeEditor theme={activeProject.theme} onChange={(theme: PDFTheme) => !isReadOnly && updateActiveProject({ theme })} />
                        </div>
                     </div>
                   )}
                </div>
             </div>
          </div>
        )}
      </main>

      {/* PRINT MODAL (HIDDEN) */}
      {activeProject && (
        <PrintReport project={activeProject} data={flattenedList} stats={stats} />
      )}

      {/* MODAL: SUMÁRIO DE IMPORTAÇÃO */}
      {importSummary && (
        <div className="fixed inset-0 z-[500] flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-xl animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 w-full max-w-lg rounded-[2.5rem] p-8 sm:p-12 shadow-2xl border border-white/10">
            <div className="flex items-center gap-6 mb-8 text-emerald-500">
              <div className="p-4 bg-emerald-500/10 rounded-2xl"><CheckCircle2 size={40} /></div>
              <h3 className="text-xl font-black uppercase tracking-tight text-slate-800 dark:text-white">Planilha Lida</h3>
            </div>
            
            <div className="grid grid-cols-2 gap-4 mb-8">
              <div className="bg-indigo-50 dark:bg-indigo-900/20 p-6 rounded-3xl text-center border border-indigo-100 dark:border-indigo-800">
                <p className="text-2xl font-black text-indigo-600">{importSummary.stats.categories}</p>
                <p className="text-[9px] font-black text-indigo-400 uppercase tracking-widest">Grupos</p>
              </div>
              <div className="bg-emerald-50 dark:bg-emerald-900/20 p-6 rounded-3xl text-center border border-emerald-100 dark:border-emerald-800">
                <p className="text-2xl font-black text-emerald-600">{importSummary.stats.items}</p>
                <p className="text-[9px] font-black text-emerald-400 uppercase tracking-widest">Itens</p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <button onClick={() => setImportSummary(null)} className="flex-1 py-4 text-xs font-black uppercase text-slate-400 hover:text-slate-600 transition-colors">Cancelar</button>
              <button onClick={() => { activeProject && updateActiveProject({ items: [...activeProject.items, ...importSummary.items] }); setImportSummary(null); }} className="flex-[2] py-4 bg-emerald-600 text-white rounded-2xl text-xs font-black uppercase shadow-xl shadow-emerald-500/20 active:scale-95 transition-all">Importar Tudo</button>
            </div>
          </div>
        </div>
      )}

      {activeProject && isModalOpen && (
        <WorkItemModal 
          isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onSave={(data) => {
            if (editingItem) {
              updateActiveProject({ items: activeProject.items.map(it => it.id === editingItem.id ? { ...it, ...data } : it) });
            } else {
              const parentId = targetParentId || data.parentId || null;
              const newItem: WorkItem = {
                id: crypto.randomUUID(), parentId, name: data.name || 'Novo Registro', type: data.type || modalType, wbs: '', order: activeProject.items.filter(i => i.parentId === parentId).length,
                unit: data.unit || 'un', contractQuantity: data.contractQuantity || 0, unitPrice: 0, unitPriceNoBdi: data.unitPriceNoBdi || 0, contractTotal: 0,
                previousQuantity: 0, previousTotal: 0, currentQuantity: 0, currentTotal: 0, currentPercentage: 0,
                accumulatedQuantity: 0, accumulatedTotal: 0, accumulatedPercentage: 0, balanceQuantity: 0, balanceTotal: 0
              };
              updateActiveProject({ items: [...activeProject.items, newItem] });
              if (newItem.parentId) setExpandedIds(new Set([...expandedIds, newItem.parentId]));
            }
          }} 
          editingItem={editingItem} type={modalType} categories={activeProject.items.filter(i => i.type === 'category') || []} 
          projectBdi={activeProject.bdi || 0} 
        />
      )}

      {deleteModal.isOpen && (
        <div className="fixed inset-0 z-[150] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
           <div className="bg-white dark:bg-slate-900 w-full max-w-sm rounded-[2.5rem] p-10 shadow-2xl text-center">
              <div className="w-16 h-16 bg-rose-100 dark:bg-rose-900/30 text-rose-600 rounded-full flex items-center justify-center mx-auto mb-6"><Trash2 size={24} /></div>
              <h3 className="text-xl font-black mb-4 tracking-tight dark:text-white">Excluir Obra?</h3>
              <p className="text-xs text-slate-500 mb-10">Todos os dados e histórico serão permanentemente apagados.</p>
              <div className="flex gap-3">
                <button onClick={() => setDeleteModal({isOpen: false, id: ''})} className="flex-1 py-4 text-xs font-black uppercase text-slate-400">Voltar</button>
                <button onClick={() => { 
                   const remaining = projects.filter(p => p.id !== deleteModal.id);
                   updateProjects(remaining);
                   if (activeProjectId === deleteModal.id) {
                     setActiveProjectId(null);
                     setViewMode('global-dashboard');
                   }
                   setDeleteModal({isOpen: false, id: ''});
                }} className="flex-1 py-4 bg-rose-600 text-white rounded-2xl text-xs font-black uppercase shadow-lg shadow-rose-500/20 active:scale-95 transition-all">Excluir</button>
              </div>
           </div>
        </div>
      )}

      {renameModal.isOpen && (
        <div className="fixed inset-0 z-[150] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in">
           <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-[2.5rem] p-8 shadow-2xl">
              <h3 className="text-xl font-black tracking-tight dark:text-white mb-6">Nome da Obra</h3>
              <input autoFocus className="w-full px-6 py-4 rounded-2xl border border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-bold mb-8 outline-none focus:border-indigo-500 text-sm dark:text-white" value={renameModal.name} onChange={e => setRenameModal({...renameModal, name: e.target.value})} onKeyDown={(e) => { if(e.key === 'Enter') { updateProjects(projects.map(p => p.id === renameModal.id ? {...p, name: renameModal.name} : p)); setRenameModal({isOpen: false, id: '', name: ''}); } }} />
              <div className="flex gap-3">
                <button onClick={() => setRenameModal({isOpen: false, id: '', name: ''})} className="flex-1 py-4 text-xs font-black uppercase text-slate-400">Cancelar</button>
                <button onClick={() => { updateProjects(projects.map(p => p.id === renameModal.id ? {...p, name: renameModal.name} : p)); setRenameModal({isOpen: false, id: '', name: ''}); }} className="flex-1 bg-indigo-600 text-white rounded-2xl text-xs font-black uppercase shadow-lg shadow-indigo-500/20 active:scale-95 transition-all">Salvar</button>
              </div>
           </div>
        </div>
      )}

      {closeMeasurementModal && activeProject && (
        <div className="fixed inset-0 z-[150] flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-in fade-in">
           <div className="bg-white dark:bg-slate-900 w-full max-w-lg rounded-[2.5rem] p-8 sm:p-12 shadow-2xl border border-white/10 text-center">
              <div className="w-20 h-20 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 rounded-full flex items-center justify-center mx-auto mb-8"><Lock size={32} /></div>
              <h3 className="text-2xl font-black text-slate-800 dark:text-white mb-4 uppercase tracking-tighter">Encerrar Período?</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400 mb-10 leading-relaxed">A medição <strong>#{activeProject.measurementNumber}</strong> será congelada.<br/>O valor total é <strong>{financial.formatBRL(stats.current)}</strong>.</p>
              <div className="flex flex-col sm:flex-row gap-3">
                <button onClick={() => setCloseMeasurementModal(false)} className="py-4 text-xs font-black uppercase text-slate-400 hover:text-slate-600 transition-colors">Voltar</button>
                <button onClick={() => { finalizeMeasurement(); setCloseMeasurementModal(false); }} className="flex-1 py-4 bg-indigo-600 text-white rounded-2xl text-xs font-black uppercase shadow-xl shadow-indigo-500/20 active:scale-95 transition-all">Confirmar Encerramento</button>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

const NavItem = ({ active, onClick, icon, label, open }: any) => (
  <button onClick={onClick} className={`w-full flex items-center gap-4 p-3.5 rounded-2xl transition-all ${active ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-slate-200'}`}>
    <div className="shrink-0">{icon}</div>
    {open && <span className="text-[11px] font-bold uppercase tracking-widest truncate text-left">{label}</span>}
  </button>
);

const TabBtn = ({ active, onClick, label, icon }: any) => (
  <button onClick={onClick} className={`flex items-center gap-2 px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${active ? 'bg-white dark:bg-slate-700 text-indigo-600 shadow-sm' : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'}`}>
    {icon} <span className="hidden sm:inline">{label}</span>
  </button>
);

const KpiCard = ({ label, value, icon, progress, color, highlight = false }: any) => {
  const colors: any = { indigo: 'text-indigo-600', blue: 'text-blue-600', emerald: 'text-emerald-600', rose: 'text-rose-600', slate: 'text-slate-600' };
  return (
    <div className={`p-6 sm:p-8 rounded-[2rem] border shadow-sm hover:shadow-xl transition-all relative overflow-hidden group ${highlight ? 'bg-slate-50 border-indigo-200 dark:bg-indigo-950/10 dark:border-indigo-900' : 'bg-white border-slate-200 dark:bg-slate-900 dark:border-slate-800'}`}>
      <div className="flex justify-between items-start mb-4 sm:mb-6 relative z-10">
        <div className={`p-2 sm:p-3 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-400 group-hover:${colors[color]} transition-colors`}>{icon}</div>
        <span className="text-[8px] sm:text-[9px] font-black uppercase tracking-widest text-slate-400">{label}</span>
      </div>
      <p className={`text-xl sm:text-2xl font-black tracking-tighter mb-4 relative z-10 ${colors[color]}`}>{value}</p>
      <div className="w-full h-1 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden relative z-10">
        <div className="h-full bg-current opacity-70 transition-all duration-1000" style={{ width: `${Math.min(100, Math.abs(progress || 0))}%`, color: `var(--tw-text-opacity)` }} />
      </div>
    </div>
  );
};

export default App;
