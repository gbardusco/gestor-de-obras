
import React, { useState, useEffect } from 'react';
import { WorkItem, ItemType } from '../types';
import { financial } from '../utils/math';
import { X, Save, AlertCircle, Briefcase, Layers, Package, FolderTree, Percent } from 'lucide-react';
import { z } from 'zod';

const WorkItemSchema = z.object({
  name: z.string().min(3, "Mínimo 3 letras").max(200, "Muito longo"),
  type: z.enum(['category', 'item']),
  parentId: z.string().nullable().optional(),
  unit: z.string().optional(),
  contractQuantity: z.number().min(0, "Mínimo 0"),
  unitPriceNoBdi: z.number().min(0, "Mínimo 0"),
  unitPrice: z.number().min(0, "Mínimo 0"),
  currentPercentage: z.number().min(0).max(100).optional(),
}).refine((data) => data.type === 'category' || (data.unit && data.unit.trim().length > 0), {
  message: "Unidade obrigatória",
  path: ["unit"],
});

interface WorkItemModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: Partial<WorkItem>) => void;
  editingItem: WorkItem | null;
  type: ItemType;
  categories: WorkItem[];
  projectBdi: number;
}

export const WorkItemModal: React.FC<WorkItemModalProps> = ({
  isOpen, onClose, onSave, editingItem, type: initialType, categories, projectBdi
}) => {
  const [activeType, setActiveType] = useState<ItemType>(initialType);
  const [formData, setFormData] = useState<Partial<WorkItem>>({
    name: '', parentId: null, unit: '', contractQuantity: 0, unitPrice: 0, unitPriceNoBdi: 0, cod: '', fonte: 'Próprio'
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (editingItem) {
      setFormData(editingItem);
      setActiveType(editingItem.type);
    } else {
      setFormData({ name: '', parentId: null, unit: initialType === 'item' ? 'un' : '', contractQuantity: 0, unitPrice: 0, unitPriceNoBdi: 0, cod: '', fonte: 'Próprio' });
      setActiveType(initialType);
    }
    setErrors({});
  }, [editingItem, initialType, isOpen]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    let finalValue: any = value;
    if (type === 'number') finalValue = value === '' ? 0 : parseFloat(value);
    if (name === 'parentId') finalValue = value === "" ? null : value;
    setFormData(prev => ({ ...prev, [name]: finalValue }));
  };

  const handleSubmit = () => {
    const result = WorkItemSchema.safeParse({ ...formData, type: activeType });
    if (result.success) {
      onSave({ ...formData, type: activeType });
      onClose();
    } else {
      const newErrors: Record<string, string> = {};
      result.error.issues.forEach(issue => { if (issue.path[0]) newErrors[issue.path[0].toString()] = issue.message; });
      setErrors(newErrors);
    }
  };

  if (!isOpen) return null;
  const isCategory = activeType === 'category';

  return (
    <div className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-300">
      <div className="bg-white dark:bg-slate-900 w-full max-w-2xl sm:rounded-[2.5rem] shadow-2xl border-t sm:border border-slate-200 dark:border-slate-800 flex flex-col max-h-[95vh]">
        <div className="px-6 sm:px-10 pt-6 sm:pt-8 pb-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-xl ${isCategory ? 'bg-blue-600' : 'bg-emerald-600'} text-white`}>
              {isCategory ? <Layers size={20} /> : <Package size={20} />}
            </div>
            <div>
              <h2 className="text-lg font-black dark:text-white">{editingItem ? 'Editar' : 'Novo'} Registro</h2>
              <p className="text-[9px] text-slate-500 font-bold uppercase tracking-widest">Painel EAP</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-all"><X size={20} /></button>
        </div>

        <div className="p-6 sm:p-10 space-y-6 overflow-y-auto custom-scrollbar flex-1">
          {!editingItem && (
            <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-xl gap-1">
              <button onClick={() => setActiveType('category')} className={`flex-1 py-2.5 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all ${activeType === 'category' ? 'bg-white dark:bg-slate-700 text-blue-600 shadow-sm' : 'text-slate-500'}`}>Categoria</button>
              <button onClick={() => setActiveType('item')} className={`flex-1 py-2.5 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all ${activeType === 'item' ? 'bg-white dark:bg-slate-700 text-emerald-600 shadow-sm' : 'text-slate-500'}`}>Serviço</button>
            </div>
          )}

          <div className="space-y-4">
            <div>
              <label className="text-[9px] font-black text-slate-400 uppercase mb-2 block">Descrição</label>
              <textarea name="name" rows={2} className="w-full px-5 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 dark:text-white text-sm font-medium outline-none focus:border-blue-500" value={formData.name} onChange={handleInputChange} />
              {errors.name && <p className="text-[9px] text-rose-500 font-bold mt-1">{errors.name}</p>}
            </div>

            <div>
              <label className="text-[9px] font-black text-slate-400 uppercase mb-2 block">Pai (Hierarquia)</label>
              <select name="parentId" className="w-full px-5 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 dark:text-white text-xs font-bold outline-none" value={formData.parentId || ""} onChange={handleInputChange}>
                <option value="">Raiz do Projeto</option>
                {categories.map(cat => <option key={cat.id} value={cat.id}>{cat.wbs} - {cat.name}</option>)}
              </select>
            </div>

            {!isCategory && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-[9px] font-black text-slate-400 uppercase mb-2 block">Unidade</label>
                  <input name="unit" className="w-full px-5 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 dark:text-white text-xs font-bold text-center outline-none" value={formData.unit} onChange={handleInputChange} />
                </div>
                <div>
                  <label className="text-[9px] font-black text-slate-400 uppercase mb-2 block">Qtd Contratual</label>
                  <input name="contractQuantity" type="number" className="w-full px-5 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 dark:text-white text-xs font-bold text-center outline-none" value={formData.contractQuantity} onChange={handleInputChange} />
                </div>
                <div className="sm:col-span-2 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-700 space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-[9px] font-black text-slate-400 uppercase mb-2 block">P. Unit S/ BDI</label>
                      <input name="unitPriceNoBdi" type="number" className="w-full px-5 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 dark:text-white text-xs font-black text-right" value={formData.unitPriceNoBdi} onChange={e => {
                        const val = parseFloat(e.target.value) || 0;
                        setFormData({ ...formData, unitPriceNoBdi: val, unitPrice: financial.round(val * (1 + projectBdi/100)) });
                      }} />
                    </div>
                    <div>
                      <label className="text-[9px] font-black text-emerald-600 uppercase mb-2 block">P. Final C/ BDI</label>
                      <input name="unitPrice" type="number" className="w-full px-5 py-3 rounded-xl border border-emerald-200 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400 text-xs font-black text-right" value={formData.unitPrice} onChange={e => {
                        const val = parseFloat(e.target.value) || 0;
                        setFormData({ ...formData, unitPrice: val, unitPriceNoBdi: financial.round(val / (1 + projectBdi/100)) });
                      }} />
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="px-6 sm:px-10 py-6 sm:py-8 bg-slate-50 dark:bg-slate-800/80 border-t border-slate-100 dark:border-slate-700 flex flex-col sm:flex-row justify-end items-stretch gap-3 shrink-0">
          <button onClick={onClose} className="py-3 text-[10px] font-black text-slate-500 uppercase tracking-widest">Descartar</button>
          <button onClick={handleSubmit} className={`py-4 px-8 text-[10px] font-black text-white ${isCategory ? 'bg-blue-600' : 'bg-emerald-600'} rounded-2xl shadow-xl flex items-center justify-center gap-2 active:scale-95 transition-all`}>
            <Save size={16} /> Salvar Alterações
          </button>
        </div>
      </div>
    </div>
  );
};
